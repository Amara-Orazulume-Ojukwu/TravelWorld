/** @type {import('stylelint').Config} */
export default {
  extends: [
    'stylelint-config-twbs-bootstrap'
  ],
  plugins: [
    'stylelint-order'
  ],
  reportInvalidScopeDisables: true,
  reportNeedlessDisables: true,
  rules: {
    'selector-not-notation': 'complex',
    'selector-class-pattern': [
      '^([a-z][a-z0-9]*(-[a-z0-9]+)*:)?([a-z][a-z0-9]*)(-[a-z0-9]+)*$',
      { message: 'Expected class selector "%s" to be kebab-case (with optional breakpoint prefix)' }
    ],
    'order/order': [
      [
        { type: 'at-rule', name: 'use' },
        { type: 'at-rule', name: 'forward' },
        'dollar-variables',
        'custom-properties',
        'declarations',
        'rules'
      ]
    ]
  },
  overrides: [
    {
      files: '**/*.scss',
      rules: {
        'declaration-property-value-disallowed-list': {
          border: 'none',
          outline: 'none'
        },
        'function-disallowed-list': [
          'lighten',
          'darken'
        ],
        'property-disallowed-list': [
          'border-radius',
          'border-top-left-radius',
          'border-top-right-radius',
          'border-bottom-right-radius',
          'border-bottom-left-radius',
          'transition'
        ],
        'scss/dollar-variable-default': [
          true,
          {
            ignore: 'local'
          }
        ],
        'scss/selector-no-union-class-name': true
      }
    },
    {
      files: 'scss/**/*.{test,spec}.scss',
      rules: {
        'scss/dollar-variable-default': null,
        'declaration-no-important': null
      }
    },
    {
      files: 'site/**/*.scss',
      rules: {
        'scss/dollar-variable-default': null
      }
    },
    {
      files: 'site/**/examples/**/*.css',
      rules: {
        'comment-empty-line-before': null,
        'property-no-vendor-prefix': null,
        'selector-no-qualifying-type': null,
        'value-no-vendor-prefix': null
      }
    }
  ]
}
