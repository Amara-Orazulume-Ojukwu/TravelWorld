/* eslint-disable camelcase */

'use strict'

const path = require('node:path')

module.exports = {
  spec_dir: 'scss',
  // Make Jasmine look for `.test.scss` files
  // spec_files: ['**/*.{test,spec}.scss'],
  spec_files: [
    '**/_utilities.test.scss',
    '**/utilities/_api.test.scss',
    '**/modules/_configuration.test.scss',
    '**/modules/_config-maps.test.scss',
    '**/modules/_root-tokens.test.scss',
    '**/modules/_theme-colors.test.scss',
    '**/modules/_theme-reset.test.scss',
    '**/forms/_validation.test.scss',
    '**/mixins/_color-mode-*.test.scss'
  ],
  // Compile them into JS scripts running `sass-true`
  requires: [path.join(__dirname, 'sass-true/register.cjs')],
  // Ensure we use `require` so that the require.extensions works
  // as `import` completely bypasses it
  jsLoader: 'require'
}
