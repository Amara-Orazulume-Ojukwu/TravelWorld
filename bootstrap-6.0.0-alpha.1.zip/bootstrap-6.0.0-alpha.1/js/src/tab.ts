/**
 * --------------------------------------------------------------------------
 * Bootstrap tab.ts
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */

import BaseComponent from './base-component.js'
import EventHandler, { type BootstrapEvent } from './dom/event-handler.js'
import SelectorEngine from './dom/selector-engine.js'
import {
  getNextActiveElement, getTransitionDurationFromElement, isDisabled, setAriaAttribute
} from './util/index.js'

/**
 * Constants
 */

const NAME = 'tab'
const DATA_KEY = 'bs.tab'
const EVENT_KEY = `.${DATA_KEY}`

const EVENT_HIDE = `hide${EVENT_KEY}`
const EVENT_HIDDEN = `hidden${EVENT_KEY}`
const EVENT_SHOW = `show${EVENT_KEY}`
const EVENT_SHOWN = `shown${EVENT_KEY}`
const EVENT_CLICK_DATA_API = `click${EVENT_KEY}`
const EVENT_KEYDOWN = `keydown${EVENT_KEY}`
const EVENT_LOAD_DATA_API = `load${EVENT_KEY}`

const ARROW_LEFT_KEY = 'ArrowLeft'
const ARROW_RIGHT_KEY = 'ArrowRight'
const ARROW_UP_KEY = 'ArrowUp'
const ARROW_DOWN_KEY = 'ArrowDown'
const HOME_KEY = 'Home'
const END_KEY = 'End'

const CLASS_NAME_ACTIVE = 'active'
const CLASS_NAME_SHOW = 'show'
const SELECTOR_MENU_TOGGLE = '[data-bs-toggle="menu"]'
const SELECTOR_MENU = '.menu'
const NOT_SELECTOR_MENU_TOGGLE = `:not(${SELECTOR_MENU_TOGGLE})`

const SELECTOR_TAB_PANEL = '.list-group, .nav, [role="tablist"]'
const SELECTOR_OUTER = '.nav-item, .list-group-item'
const SELECTOR_INNER = `.nav-link${NOT_SELECTOR_MENU_TOGGLE}, .list-group-item${NOT_SELECTOR_MENU_TOGGLE}, [role="tab"]${NOT_SELECTOR_MENU_TOGGLE}`
const SELECTOR_DATA_TOGGLE = '[data-bs-toggle="tab"]'
const SELECTOR_INNER_ELEM = `${SELECTOR_INNER}, ${SELECTOR_DATA_TOGGLE}`

const SELECTOR_DATA_TOGGLE_ACTIVE = `.${CLASS_NAME_ACTIVE}[data-bs-toggle="tab"]`

const activationIds = new WeakMap<Element, number>()

/**
 * Class definition
 */

class Tab extends BaseComponent {
  protected declare _parent: Element | null

  constructor(element?: string | Element | null) {
    super(element)
    this._parent = this._element.closest(SELECTOR_TAB_PANEL)

    if (!this._parent) {
      throw new TypeError(`${this._element.outerHTML} has no valid parent ${SELECTOR_TAB_PANEL}`)
    }

    // Set up initial aria attributes
    this._setInitialAttributes(this._parent, this._getChildren())

    EventHandler.on(this._element, EVENT_KEYDOWN, event => this._keydown(event))
  }

  // Getters
  static override get NAME(): string {
    return NAME
  }

  // Public
  // Shows this elem and deactivate the active sibling if exists
  async show(): Promise<void> {
    const innerElem = this._element
    if (this._elemIsActive(innerElem)) {
      return
    }

    // Search for active tab on same parent to deactivate it
    const active = this._getActiveElem()

    const hideEvent = active ?
      EventHandler.trigger(active, EVENT_HIDE, { relatedTarget: innerElem }) :
      null

    const showEvent = EventHandler.trigger(innerElem, EVENT_SHOW, { relatedTarget: active })

    if (showEvent.defaultPrevented || (hideEvent && hideEvent.defaultPrevented)) {
      return
    }

    const activationId = (activationIds.get(this._parent!) || 0) + 1
    activationIds.set(this._parent!, activationId)

    this._deactivate(active, innerElem)
    await this._activate(innerElem, active, activationId)
  }

  // Private
  protected async _activate(element: HTMLElement | null, relatedElem?: HTMLElement | null, activationId?: number): Promise<void> {
    if (!element) {
      return
    }

    element.classList.add(CLASS_NAME_ACTIVE)

    // A pane animates itself in CSS, from .active. Both classes land in the same
    // frame so nothing here sequences the fade.
    if (element.getAttribute('role') !== 'tab') {
      element.classList.add(CLASS_NAME_SHOW)
      return
    }

    const pane = SelectorEngine.getElementFromSelector(element)
    this._activate(pane) // Search and activate/show the proper section

    const complete = () => {
      if (activationId !== activationIds.get(this._parent!) || !this._elemIsActive(element)) {
        return
      }

      element.removeAttribute('tabindex')
      setAriaAttribute(element, 'aria-selected', true)
      this._toggleMenu(element, true)
      EventHandler.trigger(element, EVENT_SHOWN, {
        relatedTarget: relatedElem
      })
    }

    // `shown` waits for the pane, the element that animates. The tab itself only
    // transitions its colors.
    await this._queueCallback(complete, pane ?? element, getTransitionDurationFromElement(pane) > 0)
  }

  protected async _deactivate(element: HTMLElement | null, relatedElem?: HTMLElement | null): Promise<void> {
    if (!element) {
      return
    }

    element.classList.remove(CLASS_NAME_ACTIVE)
    element.blur()

    // A pane leaves at once: two in-flow panes cannot cross-fade without one
    // stacking under the other.
    if (element.getAttribute('role') !== 'tab') {
      element.classList.remove(CLASS_NAME_SHOW)
      return
    }

    this._deactivate(SelectorEngine.getElementFromSelector(element)) // Search and deactivate the shown section too

    const complete = () => {
      setAriaAttribute(element, 'aria-selected', false)
      element.setAttribute('tabindex', '-1')
      this._toggleMenu(element, false)
      EventHandler.trigger(element, EVENT_HIDDEN, { relatedTarget: relatedElem })
    }

    await this._queueCallback(complete, element, false)
  }

  protected _keydown(event: BootstrapEvent): void {
    if (!([ARROW_LEFT_KEY, ARROW_RIGHT_KEY, ARROW_UP_KEY, ARROW_DOWN_KEY, HOME_KEY, END_KEY].includes(event.key))) {
      return
    }

    // Don't hijack modifier+arrow shortcuts (e.g. Alt+Left/Right for browser
    // history navigation); only the bare keys drive tablist navigation.
    if (event.altKey || event.ctrlKey || event.metaKey) {
      return
    }

    event.stopPropagation()// stopPropagation/preventDefault both added to support up/down keys without scrolling the page
    event.preventDefault()

    const children = this._getChildren().filter(element => !isDisabled(element))
    let nextActiveElement: HTMLElement | undefined

    if ([HOME_KEY, END_KEY].includes(event.key)) {
      nextActiveElement = event.key === HOME_KEY ? children[0] : children.at(-1)
    } else {
      const isNext = [ARROW_RIGHT_KEY, ARROW_DOWN_KEY].includes(event.key)
      nextActiveElement = getNextActiveElement(children, event.target as HTMLElement, isNext, true)
    }

    if (nextActiveElement) {
      nextActiveElement.focus({ preventScroll: true })
      Tab.getOrCreateInstance(nextActiveElement).show()
    }
  }

  protected _getChildren(): HTMLElement[] { // collection of inner elements
    return SelectorEngine.find(SELECTOR_INNER_ELEM, this._parent!)
  }

  protected _getActiveElem(): HTMLElement | null {
    return this._getChildren().find(child => this._elemIsActive(child)) || null
  }

  protected _setInitialAttributes(parent: Element, children: HTMLElement[]): void {
    this._setAttributeIfNotExists(parent, 'role', 'tablist')

    for (const child of children) {
      this._setInitialAttributesOnChild(child)
    }
  }

  protected _setInitialAttributesOnChild(child: HTMLElement): void {
    child = this._getInnerElement(child)!
    const isActive = this._elemIsActive(child)
    const outerElem = this._getOuterElement(child)
    setAriaAttribute(child, 'aria-selected', isActive)

    if (outerElem !== child) {
      this._setAttributeIfNotExists(outerElem, 'role', 'presentation')
    }

    if (!isActive) {
      child.setAttribute('tabindex', '-1')
    }

    this._setAttributeIfNotExists(child, 'role', 'tab')

    // set attributes to the related panel too
    this._setInitialAttributesOnTargetPanel(child)
  }

  protected _setInitialAttributesOnTargetPanel(child: HTMLElement): void {
    const target = SelectorEngine.getElementFromSelector(child)

    if (!target) {
      return
    }

    this._setAttributeIfNotExists(target, 'role', 'tabpanel')

    if (child.id) {
      this._setAttributeIfNotExists(target, 'aria-labelledby', `${child.id}`)
    }
  }

  protected _toggleMenu(element: HTMLElement, open: boolean): void {
    const outerElem = this._getOuterElement(element)
    const menuToggle = SelectorEngine.findOne(SELECTOR_MENU_TOGGLE, outerElem)
    if (!menuToggle) {
      return
    }

    const menu = SelectorEngine.findOne(SELECTOR_MENU, outerElem)

    menuToggle.classList.toggle(CLASS_NAME_ACTIVE, open)
    if (menu) {
      menu.classList.toggle(CLASS_NAME_SHOW, open)
    }

    setAriaAttribute(menuToggle, 'aria-expanded', open)
  }

  protected _setAttributeIfNotExists(element: Element, attribute: string, value: string): void {
    if (!element.hasAttribute(attribute)) {
      element.setAttribute(attribute, value)
    }
  }

  protected _elemIsActive(elem: HTMLElement): boolean {
    return elem.classList.contains(CLASS_NAME_ACTIVE)
  }

  // Try to get the inner element (usually the .nav-link)
  protected _getInnerElement(elem: HTMLElement): HTMLElement | null {
    return elem.matches(SELECTOR_INNER_ELEM) ? elem : SelectorEngine.findOne(SELECTOR_INNER_ELEM, elem)
  }

  // Try to get the outer element (usually the .nav-item)
  protected _getOuterElement(elem: HTMLElement): Element {
    return elem.closest(SELECTOR_OUTER) || elem
  }
}

/**
 * Data API implementation
 */

EventHandler.on(document, EVENT_CLICK_DATA_API, SELECTOR_DATA_TOGGLE, function (event) {
  if (['A', 'AREA'].includes(this.tagName)) {
    event.preventDefault()
  }

  if (isDisabled(this)) {
    return
  }

  Tab.getOrCreateInstance(this).show()
})

/**
 * Initialize on focus
 */
EventHandler.on(window, EVENT_LOAD_DATA_API, () => {
  for (const element of SelectorEngine.find(SELECTOR_DATA_TOGGLE_ACTIVE)) {
    Tab.getOrCreateInstance(element)
  }
})

export default Tab
